const mongoose = require('mongoose');
module.exports = mongoose.model('device_type', new mongoose.Schema({
 id: String,
 name: String,
 user: String,
 sensorData: Array
}));
