const mongoose =require('mongoose');
const express = require('express');
const app = express();

const bodyParser=require('body-parser');
app.use(bodyParser.urlencoded({extended:false}))
app.use(bodyParser.json())

mongoose.connect(process.env.MONGO_URL,
{useNewUrlParser:true, useUnifiedTopology:true});

const light=require('./models/light');
const temperature=require('./models/temperature');

const port = process.env.PORT || 5000;

app.use(function(req,res,next){
  res.header("Access-Control-Allow-Origin","*");
  res.header("Access-Control-Allow-headers","Origin,X-Requested-With,Content-Type,Accept");
  next();
});

app.get('/api/test', (req, res) => {
 res.send('The API is working!');
});

app.get('/api/light', (req, res) => {
  light.find({}, (err, light) => {
  if(err=true){
    return res.send(err);
  }
  else{
    return res.send(light);
  }
  });
 });
 app.post('/api/authenticate', (req, res) => {
  const {user, password} = req.body;
  console.log(req.body);
  User.findOne({name:user},(err,found) => {
  if( err )
  {
      return res.send(err);
  }
  else if(!found)
  {
      return res.send('Sorry. We cant find any such username');
  }
  else if(found.password != password)
  {
      return res.send('The password is invalid');
  }
  else
  {
      return res.json({
          success: true,
          message: 'Authenticated successfully',
          isAdmin: found.isAdmin
         });
      }
});
}); 

app.post('/api/registration', (req, res) => {
  const {user, password,isAdmin} = req.body;
  console.log(req.body);
  User.findOne({name:user},(err,found) => {
    if( err )
    {
      return res.send(err);
    }
    else if(found)
    {
      return res.send('User already exists');
    }
    else{
    const newUser = new User({
      name: user,
      password,
      isAdmin
    });
    newUser.save(err => {
      return err
      ? res.send(err)
      : res.json({
        success: true,
        message: 'Created new user'
      });
    });
  }
  });
});

app.get('/api/temperature', (req, res) => {
  temperature.find({}, (err, temperature) => {
    if(err=true){
      return res.send(err);
    }
    else{
      return res.send(temperature);
    }
  });
 });

app.post('/api/light', (req, res) => {
  const { name, user, sensorData } = req.body;
  const newlight = new light({
    name,
    user,
    sensorData
  });
  newlight.save(err=>{
    return err
    ?res.send(err)
    :res.send('successfully added light');
  });
});

app.post('/api/temperature', (req, res) => {
  const { name, user, sensorData } = req.body;
  const newtemperature = new temperature({
    name,
    user,
    sensorData
  });
  newtemperature.save(err=>{
    return err
    ?res.send(err)
    :res.send('successfully added temperature');
  });
 });

 app.post('/api/authenticate', (req, res) => {
  const {user, password} = req.body;
  console.log(req.body);
  User.findOne({name:user},(err,found) => {
  if( err )
  {
      return res.send(err);
  }
  else if(!found)
  {
      return res.send('Sorry. We cant find any such username');
  }
  else if(found.password != password)
  {
      return res.send('The password is invalid');
  }
  else
  {
      return res.json({
          success: true,
          message: 'Authenticated successfully',
          isAdmin: found.isAdmin
         });
  }
});
});  

app.post('/api/registration', (req, res) => {
  const {user, password,isAdmin} = req.body;
  console.log(req.body);
User.findOne({name:user},(err,found) => {
if( err )
{
  return res.send(err);
}
else if(found)
{
  return res.send('User already exists');
}
else{
const newUser = new User({
  name: user,
  password,
  isAdmin
 });
 newUser.save(err => {
  return err
  ? res.send(err)
  : res.json({
  success: true,
  message: 'Created new user'
  });
 });
}
});
});

app.listen(port, () => {
 console.log(`listening on port ${port}`);
});
