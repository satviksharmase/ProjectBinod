

const API_URL='http://localhost:5000/api';

const currentUser = localStorage.getItem('user');

$('#register').on('click', () => 
{
   const user = $('#user').val();
   const password = $('#password').val();
   const confirm_password = $('#confirm_password').val();
   if (password !== confirm_password) 
   {
      $('#message').append('<p class="alert alert-danger">Passwords do not match</p>');
   } 
   else 
   {
      $.post(`${API_URL}/registration`, { user, password })
      .then((response) =>
      {
         if (response.success) 
         {
            location.href = '/login';
         } 
         else 
         {
            $('#message').append(`<p class="alert alert-danger">${response}</p>`);
         }
      });
   }
});

$('#login').on('click', () => 
{
	const user = $('#user').val();
	const password = $('#password').val();
	$.post(`${API_URL}/authenticate`, { user, password })
   .then((response) =>
   {
      if (response.success) 
      {
		   localStorage.setItem('user', user);
			localStorage.setItem('isAdmin', response.isAdmin);
			localStorage.setItem('isAuthenticated', true);
		   location.href = '/';
      } 
      else 
      {
		   $('#message').append(`<p class="alert alert-danger">${response}</p>`);
      }
  }); 
});

const logout = () => 
{
   localStorage.removeItem('user');
   localStorage.removeItem('isAuthenticated');
   location.href = '/login';
}