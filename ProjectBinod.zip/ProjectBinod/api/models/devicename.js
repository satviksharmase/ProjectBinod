const mongoose = require('mongoose');
module.exports = mongoose.model('device_name', new mongoose.Schema({
 id: String,
 name: String,
 user: String,
 sensorData: Array
}));
